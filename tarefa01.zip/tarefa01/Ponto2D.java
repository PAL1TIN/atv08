package tarefa01;

public class Ponto2D {
	private double x, y;

	public Ponto2D(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public Ponto2D() {
		this(0, 0);
	}

	public Ponto2D(Ponto2D p) {
		this(p.getX(), p.getY());
	}

	public double getX() {
		return this.x;
	}

	public double getY() {
		return this.y;
	}

	public void desl(double x, double y) {
		this.x += x;
		this.y += y;
	}

	public Ponto2D somaP(double x, double y) {
		return new Ponto2D(this.x + x, this.y + y);
	}

	public Ponto2D somaP(Ponto2D p) {
		return new Ponto2D(this.x + p.getX(), this.y + p.getY());
	}

	public String toString() {
		return " Ponto x: " + x + "\nPonto Y: " + y;
	}

	public Ponto2D clone() {
		return new Ponto2D(this);
	}
}

package tarefa01;

import tarefa01.Pixel;
import tarefa01.Ponto3D;
import tarefa01.Ponto2D;

public class TestePonto {
    public static void main(String[] args) {
        Ponto2D p2D = new Ponto2D(1, 5);
        Ponto3D p3D = new Ponto3D(7, 8, 9);
        Pixel p = new Pixel(2, 3, 4);

        System.out.println(p);
        p.desl(3, 2);
        System.out.println(p);
        System.out.println("--------------------");
        System.out.println(p3D);
        p3D.desl(2, 1, 0);
        System.out.println("--------------------");
        System.out.println(p3D);
        System.out.println("--------------------");

        System.out.println(p2D);
        p2D.desl(-2, 4);
        System.out.println("--------------------");
        System.out.println(p2D);
    }
}